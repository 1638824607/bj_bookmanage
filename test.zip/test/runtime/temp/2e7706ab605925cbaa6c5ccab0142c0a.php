<?php if (!defined('THINK_PATH')) exit(); /*a:1:{s:90:"C:\phpStudy\PHPTutorial\WWW\test\public/../application/index\view\book\book_user_list.html";i:1550142141;}*/ ?>
<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8">
    <title>类别列表</title>
    <meta name="renderer" content="webkit">
    <meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, minimum-scale=1.0, maximum-scale=1.0, user-scalable=0">
    <link rel="stylesheet" href="/static/admin/lib/layui/css/layui.css" media="all">
    <link rel="stylesheet" href="/static/admin/css/admin.css" media="all">
</head>
<body>
<div class="layui-fluid">
    <div class="layui-card">
        <div class="layui-form layui-card-header layuiadmin-card-header-auto">
            <div class="layui-form-item">
                <div class="layui-inline">
                    <label class="layui-form-label">图书编号</label>
                    <div class="layui-input-inline">
                        <input type="text" name="book_cert" placeholder="请输入图书编号" autocomplete="off" class="layui-input">
                    </div>
                </div>

                <div class="layui-inline">
                    <label class="layui-form-label">图书名称</label>
                    <div class="layui-input-inline">
                        <input type="text" name="book_name" placeholder="请输入图书名称" autocomplete="off" class="layui-input">
                    </div>
                </div>

                <div class="layui-inline">
                    <button class="layui-btn layuiadmin-btn-list" lay-submit lay-filter="book-search-form-submit">
                        <i class="layui-icon layui-icon-search layuiadmin-button-btn"></i>
                    </button>
                </div>
            </div>
        </div>
        <div class="layui-card-body">
            <div>
                <table id="list_table" lay-filter="list_table"></table>
            </div>
        </div>
    </div>
</div>

<script src="/static/admin/lib/layui/layui.js"></script>
<script>
    var book_table_url = '<?php echo url("book/book_table"); ?>';
    var book_save  = '<?php echo url("book/book_save"); ?>';

    layui.use(['jquery','table','form', 'upload'], function() {
        var $      = layui.$;
        var table  = layui.table;
        var form   = layui.form;
        var layer   = layui.layer;

        var cateList = <?php echo json_encode($cateList); ?>;
        var publicList = <?php echo json_encode($publicList); ?>;
        var placeList = <?php echo json_encode($placeList); ?>;


        // 数据表格渲染
        table.render({
            elem: '#list_table'
            ,url: book_table_url //数据接口
            ,method:'post'
            ,page: true //开启分页
            ,limit:20  //每页行数 默认10
            ,limits: [10, 20, 30]
            ,cols: [[ //表头
                {field : 'book_cert', title: '图书编号', sort: true}
                ,{field : 'book_name',width:250, title: '图书名称'}
                ,{field : 'book_cate', title: '图书类别',templet:function(d){
                    var cateName = cateList[d.book_cate] ?  cateList[d.book_cate]['cate_name'] : '已屏蔽';
                    return "<div>" + cateName+"</div>"
                }}
                ,{field : 'book_public', width:200,title: '出版社',templet:function(d){
                    var publicName = publicList[d.book_public] ?  publicList[d.book_public]['public_name'] : '已屏蔽';
                    return "<div>" + publicName+"</div>"
                }}
                ,{field : 'book_place', title: '书架位置',templet:function(d){
                    var placeName = placeList[d.book_place] ?  placeList[d.book_place]['place_name'] : '已屏蔽';
                    return "<div>" + placeName+"</div>"
                }}
                ,{field : 'book_num', title: '图书库存'}
                ,{field : 'book_now_num', title: '当前库存'}
                ,{field : 'book_total_out', title: '借出次数'}
                ,{field: 'book_status',  title: '状态',templet:'<div>{{d.book_status == 1 ? "屏蔽" : "正常"}}</div>'}

            ]]
        });

        $('.form-add').on('click', function()
        {
            form.val('form-data',{
                'book_id' : '',
                'book_cert' : '',
                'book_name' : '',
                'book_cate' : '',
                'book_public' : '',
                'book_place' : '',
                'book_num' : '',
                'book_status' : ''
            });

            layer.open({
                type: 1
                ,title: '添加图书'
                ,content: $('#form-data')
                ,maxmin: true
                ,area: ['850px', '650px']
                ,btn: ['确定', '取消']
                ,yes: function(index, layero){
                    $('#form-submit').click();
                }
            });
        });

        form.on('submit(book-search-form-submit)', function(data){
            var field = data.field;

            //执行重载
            table.reload('list_table', {
                where: field,
                page: {curr: 1}
            });
        });

        table.on('tool(list_table)', function(obj)
        {
            var data = obj.data;

            if(obj.event === 'edit')
            {
                form.val('form-data',{
                    'book_id' : data.book_id,
                    'book_cert' : data.book_cert,
                    'book_name' : data.book_name,
                    'book_cate' : data.book_cate,
                    'book_public' : data.book_public,
                    'book_place' : data.book_place,
                    'book_num' : data.book_num,
                    'book_status' : data.book_status
                });

                layer.open({
                    type: 1
                    ,title: '修改图书'
                    ,content: $('#form-data')
                    ,maxmin: true
                    ,area: ['850px', '650px']
                    ,btn: ['确定', '取消']
                    ,yes: function(index, layero){
                        $('#form-submit').click();
                    }
                });
            }
        });

        form.on('submit(form-submit)', function(data)
        {

            $.post(
                book_save,
                data.field,
                function(res){
                    layer.msg(res.msg, {shade:0.1,time:1500}, function(){
                        if(res.code == 1)
                        {
                            table.reload('list_table'); //重载表格
                            layer.closeAll();
                        }


                    });
                },'json'
            );
        });
    });
</script>
</body>
</html>