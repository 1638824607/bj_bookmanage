<?php if (!defined('THINK_PATH')) exit(); /*a:1:{s:87:"C:\phpStudy\PHPTutorial\WWW\test\public/../application/index\view\system\pass_form.html";i:1547894907;}*/ ?>
<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8">
    <title>网站设置</title>
    <meta name="renderer" content="webkit">
    <meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, minimum-scale=1.0, maximum-scale=1.0, user-scalable=0">
    <link rel="stylesheet" href="/static/admin/lib/layui/css/layui.css" media="all">
    <link rel="stylesheet" href="/static/admin/css/admin.css" media="all">
    <script src="/static/admin/lib/layui/layui.js"></script>
</head>
<body>

<div class="layui-fluid">
    <div class="layui-row layui-col-space15">
        <div class="layui-col-md12">
            <div class="layui-card">
                <div class="layui-card-header">更改密码</div>
                <div class="layui-card-body" pad15>

                    <div class="layui-form" wid100 lay-filter="">
                        <div class="layui-form-item">
                            <label class="layui-form-label">密码</label>
                            <div class="layui-input-inline">
                                <input type="text" autocomplete="off" placeholder="请输入1-12个字符" name="user_pass" maxlength="12" value="" lay-verify="required" class="layui-input">
                            </div>
                        </div>

                        <div class="layui-form-item">
                            <div class="layui-input-block">
                                <button class="layui-btn" lay-submit lay-filter="set_website">确认保存</button>
                            </div>
                        </div>
                    </div>

                </div>


            </div>
        </div>
    </div>
</div>

</body>
</html>

<script>
    layui.use(['jquery','element','layer','form', 'upload'], function() {
        var form = layui.form;
        var $ = layui.jquery;
        var layer = layui.layer;

        var pass_save_url = '<?php echo url("system/pass_save"); ?>';

        form.on('submit(set_website)', function(data)
        {
            $.post(
                pass_save_url,
                data.field,
                function(res){
                    layer.msg(res.msg, {shade:0.1,time:1500}, function(){
                        if(res.code == 1)
                        {
                            layer.closeAll();
                            window.location.reload();
                        }

                    });
                },'json'
            );
        });
    });
</script>