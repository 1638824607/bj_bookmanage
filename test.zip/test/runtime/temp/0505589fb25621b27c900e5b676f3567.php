<?php if (!defined('THINK_PATH')) exit(); /*a:1:{s:86:"C:\phpStudy\PHPTutorial\WWW\test\public/../application/index\view\index\book_rank.html";i:1550111138;}*/ ?>
<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8">
    <title>图书排行榜</title>
    <meta name="renderer" content="webkit">
    <meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, minimum-scale=1.0, maximum-scale=1.0, user-scalable=0">
    <link rel="stylesheet" href="/static/admin/lib/layui/css/layui.css" media="all">
    <link rel="stylesheet" href="/static/admin/css/admin.css" media="all">
    <script src="/static/admin/js/echarts.min.js"></script>
</head>
<body>

<div class="layui-fluid">
    <div class="layui-row layui-col-space15">
        <div class="layui-col-md6">
            <div class="layui-card">
                <div class="layui-card-body">
                    <div id="LAY-index-normline" style="width: 100%;height:350px;"></div>
                </div>
            </div>
        </div>
        <div class="layui-col-md6">
            <div class="layui-card">
                <div class="layui-card-body">
                    <div class="layui-card">
                            <div id="LAY-index-normline2" style="width: 100%;height:350px;"></div>
                    </div>

                </div>
            </div>
        </div>



    </div>
    <div class="layui-row layui-col-space15">
        <div class="layui-col-md12">
            <div class="layui-card">
                <div class="layui-card-body">
                    <div id="LAY-index-normline1" style="width: 100%;height:350px;"></div>
                </div>
            </div>
        </div>
        <!--<div class="layui-col-md6">-->
            <!--<div class="layui-card">-->
                <!--<div class="layui-card-body">-->
                    <!--<div class="layui-card">-->
                        <!--<div id="LAY-index-normline2" style="width: 100%;height:350px;"></div>-->
                    <!--</div>-->

                <!--</div>-->
            <!--</div>-->
        <!--</div>-->



    </div>
</div>


<!--<div class==layui-col-md12>-->
    <!--<div class="layui-card">-->
        <!--<div class="layui-card-body">-->
            <!--<div id="LAY-index-normline1" style="width: 100%;height:350px;"></div>-->
        <!--</div>-->
    <!--</div>-->
<!--</div>-->

<script src="/static/admin/lib/layui/layui.js"></script>
<script src="/static/js/jquery.min.js"></script>

<script>
    layui.config({
        base: '/static/admin/' //静态资源所在路径
    }).extend({
        index: 'js/index' //主入口模块
    }).use(['index']);
</script>
<script type="text/javascript">
    // 基于准备好的dom，初始化echarts实例
    var myChart1 = echarts.init(document.getElementById('LAY-index-normline'));
    var myChart2 = echarts.init(document.getElementById('LAY-index-normline2'));
    var myChart3 = echarts.init(document.getElementById('LAY-index-normline1'));


    var weekArr = {1:6,2:0,3:1,4:2,5:3,6:4,7:5};

    // 指定图表的配置项和数据
    var option1 = {
        title: {
            text: '本周图书借出曲线'
        },
        tooltip: {},
        legend: {
            data:['借出量']
        },
        xAxis: {
            data: ["周一","周二","周三","周四","周五","周六","周日"]
        },
        yAxis: {
            minInterval: 1
        },
        series: [{
            name: '借出量',
            type: 'bar'
        }]
    };
    var option2 = {
        title: {
            text: '本月图书借出曲线'
        },
        tooltip: {},
        legend: {
            data:['借出量']
        },
        xAxis: {
//            data: ["周一","周二","周三","周四","周五","周六","周日","周日","周日","周日","周日","周日","周日"]
        },
        yAxis: {
            minInterval: 1
        },
        series: [{
            name: '借出量',
            type: 'bar'
        }]
    };

    var option3 = {
        title: {
            text: '图书借出总排行'
        },
        tooltip: {},
        legend: {
            data:['借出量']
        },
        xAxis: {
//            data: ["图书一","图书二","图书三","图书四","图书五","图书六",
//                "图书七",
//                "图书七",
//                "图书七",
//                "图书七",
//                "图书七",
//                "图书七",
//                "图书七",
//                "图书七",
//                "图书七",
//                "图书七",
//            ]
        },
        yAxis: {minInterval: 1},
        series: [{
            name: '借出量',
            type: 'bar',
//            data: [4115, 3120, 1136, 999, 787, 678,
//                543,
//                347,
//                312,
//                298,
//                276,
//                256,
//                233,
//                168,
//                89,
//                13
//            ]
        }]
    };

    $.post(
        "<?php echo url('ajax_book_rank'); ?>",
        function(res){
            if(! $.isEmptyObject(res['lend_week']))
            {
                option1['series'][0]['data'] = [];
                $.each(res['lend_week'], function(k,v){
                    option1['series'][0]['data'][weekArr[v.week]] = v.lend_num;
                });
            }

            if(! $.isEmptyObject(res['lend_month']))
            {
                option2['series'][0]['data'] = [];
                option2['xAxis']['data'] = [];
                $.each(res['lend_month'], function(k1,v1){
                    option2['series'][0]['data'][k1] = v1.lend_num;
                    option2['xAxis']['data'][k1] = v1.created_day;
                });
            }

            if(! $.isEmptyObject(res['lend_book']))
            {
                option3['series'][0]['data'] = [];
                option3['xAxis']['data'] = [];
                $.each(res['lend_book'], function(k1,v1){
                    option3['series'][0]['data'][k1] = v1.lend_num;
                    option3['xAxis']['data'][k1] = v1.book_name;
                });
            }

            myChart1.setOption(option1);
            myChart2.setOption(option2);
            myChart3.setOption(option3);
        },'json'
    );

    // 使用刚指定的配置项和数据显示图表。

</script>
</body>
</html>



