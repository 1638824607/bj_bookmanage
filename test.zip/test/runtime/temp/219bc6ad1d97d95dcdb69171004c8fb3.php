<?php if (!defined('THINK_PATH')) exit(); /*a:1:{s:90:"C:\phpStudy\PHPTutorial\WWW\test\public/../application/index\view\lend\lend_user_list.html";i:1550142425;}*/ ?>
<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8">
    <title>类别列表</title>
    <meta name="renderer" content="webkit">
    <meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, minimum-scale=1.0, maximum-scale=1.0, user-scalable=0">
    <link rel="stylesheet" href="/static/admin/lib/layui/css/layui.css" media="all">
    <link rel="stylesheet" href="/static/admin/css/admin.css" media="all">
</head>
<body>
<div class="layui-fluid">
    <div class="layui-card">
        <div class="layui-form layui-card-header layuiadmin-card-header-auto">
            <div class="layui-form-item">
                <div class="layui-inline">
                    <label class="layui-form-label">图书编号</label>
                    <div class="layui-input-inline">
                        <input type="text" name="book_cert" placeholder="请输入图书编号" autocomplete="off" class="layui-input">
                    </div>
                </div>

                <div class="layui-inline">
                    <label class="layui-form-label">图书名称</label>
                    <div class="layui-input-inline">
                        <input type="text" name="book_name" placeholder="请输入图书名称" autocomplete="off" class="layui-input">
                    </div>
                </div>

                <div class="layui-inline">
                    <label class="layui-form-label">借阅状态</label>
                    <div class="layui-input-inline">
                        <select name="lend_status">
                            <option value=""></option>
                            <option value="1">借阅中</option>
                            <option value="2">已归还</option>
                        </select>
                    </div>
                </div>

                <div class="layui-inline">
                    <button class="layui-btn layuiadmin-btn-list" lay-submit lay-filter="book-search-form-submit">
                        <i class="layui-icon layui-icon-search layuiadmin-button-btn"></i>
                    </button>
                </div>
            </div>
        </div>
        <div class="layui-card-body">
            <div>
                <table id="list_table" lay-filter="list_table"></table>
            </div>
        </div>
    </div>
</div>

<script src="/static/admin/lib/layui/layui.js"></script>
<script>
    var lend_table_url = '<?php echo url("lend/lend_user_table"); ?>';
    var lend_save  = '<?php echo url("lend/lend_save"); ?>';

    var user_name = '';
    var book_cert = '';

    layui.use(['jquery','table','form', 'upload'], function() {
        var $      = layui.$;
        var table  = layui.table;
        var form   = layui.form;
        var layer   = layui.layer;

        var lend_add = "<?php echo url('lend/lend_add'); ?>";
        var lend_status_url = "<?php echo url('lend/lend_status'); ?>";
        var lendBookUrl = "<?php echo url('lend/lend_book'); ?>";

        var lendStatusArr = {1:'借阅中',2:'已归还',3:'续借中'};

        var cateList = <?php echo json_encode($cateList); ?>;
        var publicList = <?php echo json_encode($publicList); ?>;
        var placeList = <?php echo json_encode($placeList); ?>;

        table.render({
            elem: '#list_table'
            ,url: lend_table_url //数据接口
            ,method:'post'
            ,page: true //开启分页
            ,limit:20  //每页行数 默认10
            ,limits: [10, 20, 30]
            ,cols: [[ //表头
                {field : 'book_cert', title: '图书编号', sort: true}
                ,{field : 'book_name', title: '图书名称'}
                ,{field : 'book_cate', title: '图书类别',templet:function(d){
                    var cateName = cateList[d.book_cate] ? cateList[d.book_cate]['cate_name'] : '已屏蔽';
                    return "<div>" + cateName+"</div>"
                }}

                ,{field : 'book_place', title: '书架位置',templet:function(d){
                    var placeName = placeList[d.book_place] ? placeList[d.book_place]['place_name'] : '已屏蔽';
                    return "<div>" + placeName+"</div>"
                }}
                ,{field : 'user_name', title: '用户编号'}
                ,{field : 'user_nickname', title: '姓名'}
                ,{field : 'lend_status', title: '状态',templet:function(d){
                    return "<div>" + lendStatusArr[d.lend_status]+"</div>"
                }}
                ,{field : 'created_at', width:180,title: '借阅时间'}
                ,{field : 'expired_time', width:180,title: '应还时间'}
            ]]
        });

        $('.form-add').on('click', function()
        {
            form.val('form-data',{
                'book_id' : '',
                'book_cert' : '',
                'book_name' : '',
                'book_cate' : '',
                'book_public' : '',
                'book_place' : '',
                'book_num' : '',
                'book_status' : ''
            });

            layer.open({
                type: 2
                ,title: '添加图书'
                ,content:lend_add
                ,maxmin: true
                ,area: ['100%', '100%']
                ,btn: ['确定', '取消']
                ,yes: function(index, layero){
                    var lendUserName = user_name;
                    var lendBookCert = book_cert;

                    if(lendUserName == '' || lendBookCert == '') {
                        layer.msg('请选择用户或图书');
                        return false;
                    }

                    $.post(
                        lendBookUrl,
                        {book_cert: lendBookCert,user_name:lendUserName},
                        function(res){
                            layer.msg(res.msg, {shade:0.1,time:1000}, function(){
                                if(res.code == 1) {
                                    table.reload('list_table'); //重载表格
                                    layer.closeAll();
                                }
                            });
                        },'json'
                    );



                }
            });
        });

        form.on('submit(book-search-form-submit)', function(data){
            var field = data.field;

            //执行重载
            table.reload('list_table', {
                where: field,
                page: {curr: 1}
            });
        });

        table.on('tool(list_table)', function(obj)
        {
            var data = obj.data;

            var lend_id = data.lend_id;

            if(obj.event === 'return')
            {
                layer.confirm('确认执行此操作吗?', {icon: 3, title:'图书归还'}, function(index){
                    $.post(
                        lend_status_url,
                        {lend_id: lend_id,lend_status:2},
                        function(res){
                            layer.msg(res.msg, {shade:0.1,time:1500}, function(){
                                if(res.code == 1) {
                                    table.reload('list_table'); //重载表格
                                }

                                layer.closeAll();
                            });
                        },'json'
                    );
                });
            }

            if(obj.event === 'lend')
            {
                layer.confirm('确认执行此操作吗?', {icon: 3, title:'图书续借'}, function(index){
                    $.post(
                        lend_status_url,
                        {lend_id: lend_id,lend_status:3},
                        function(res){
                            layer.msg(res.msg, {shade:0.1,time:1500}, function(){
                                if(res.code == 1) {
                                    table.reload('list_table'); //重载表格
                                }

                                layer.closeAll();
                            });
                        },'json'
                    );
                });
            }
        });

        form.on('submit(form-submit)', function(data)
        {

            $.post(
                book_save,
                data.field,
                function(res){
                    layer.msg(res.msg, {shade:0.1,time:1500}, function(){
                        if(res.code == 1)
                        {
                            table.reload('list_table'); //重载表格
                            layer.closeAll();
                        }


                    });
                },'json'
            );
        });
    });
</script>
</body>
</html>