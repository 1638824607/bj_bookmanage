<?php if (!defined('THINK_PATH')) exit(); /*a:1:{s:85:"C:\phpStudy\PHPTutorial\WWW\test\public/../application/index\view\home\site_info.html";i:1547894291;}*/ ?>
<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8">
    <title>网站设置</title>
    <meta name="renderer" content="webkit">
    <meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, minimum-scale=1.0, maximum-scale=1.0, user-scalable=0">
    <link rel="stylesheet" href="/static/admin/lib/layui/css/layui.css" media="all">
    <link rel="stylesheet" href="/static/admin/css/admin.css" media="all">
    <script src="/static/admin/lib/layui/layui.js"></script>
</head>
<body>

<div class="layui-fluid">
    <div class="layui-row layui-col-space15">
        <div class="layui-col-md12">
            <div class="layui-card">
                <div class="layui-card-header">欢迎您使用</div>
                <div class="layui-card-body" pad15>

                    <table class="layui-table">
                        <tbody>
                        <tr>
                            <td>系统名称</td>
                            <td>
                                <?php echo empty($siteRow['site_name']) ? '' : $siteRow['site_name'] ?>
                            </td>
                        </tr>
                        <tr>
                            <td>开放时间</td>
                            <td><?php echo empty($siteRow['site_time']) ? '' : $siteRow['site_time'] ?></td>
                        </tr>
                        <tr>
                            <td>负责人</td>
                            <td><?php echo empty($siteRow['site_user']) ? '' : $siteRow['site_user'] ?></td>
                        </tr>
                        <tr>
                            <td>联系电话</td>
                            <td><?php echo empty($siteRow['site_tel']) ? '' : $siteRow['site_tel'] ?></td>
                        </tr>
                        <tr>
                            <td>当前时间</td>
                            <td id="current-time"><?php echo date('Y-m-d H:i:s', time()) ?></td>
                        </tr>
                        <tr>
                            <td>上次登录IP</td>
                            <td><?php echo session('user_info')['last_ip'] ?></td>
                        </tr>
                        <tr>
                            <td>上次登录时间</td>
                            <td><?php echo session('user_info')['last_time'] ?></td>
                        </tr>
                        </tbody>
                    </table>

                    <div class="layui-card">
                        <div class="layui-card-header">公告：</div>
                        <div class="layui-card-body">
                            杜甫的思想核心是儒家的仁政思想，他有“致君尧舜上，再使风俗淳”的宏伟抱负。杜甫虽然在世时名声并不显赫，但后来声名远播，对中国文学和日本文学都产生了深远的影响。杜甫共有约1500首诗歌被保留了下来，大多集于《杜工部集》。
                            <br>李清照出生于书香门第，早期生活优裕，其父李格非藏书甚富，她小时候就在良好的家庭环境中打下文学基础。出嫁后与夫赵明诚共同致力于书画金石的搜集整理。金兵入据中原时，流寓南方，境遇孤苦。所作词，前期多写其悠闲生活，后期多悲叹身世，情调感伤。形式上善用白描手法，自辟途径，语言清丽。
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

</body>
</html>

<script>
    layui.use(['jquery','element','layer','form', 'upload'], function() {
        var form = layui.form;
        var $ = layui.jquery;
        var layer = layui.layer;

        var site_save_url = '<?php echo url("home/site_save"); ?>';

        form.on('submit(set_website)', function(data)
        {
            $.post(
                site_save_url,
                data.field,
                function(res){
                    layer.msg(res.msg, {shade:0.1,time:1500}, function(){
                        if(res.code == 1)
                        {
                            layer.closeAll();
                            window.location.reload();
                        }

                    });
                },'json'
            );
        });

        function GetTime() {
            var mon, day, now, hour, min, ampm, time, str, tz, end, beg, sec;
            mon = new Array("01", "02", "03", "04", "05", "06", "07", "08",
                "09", "10", "11", "12");
            day = new Array("周日", "周一", "周二", "周三", "周四", "周五", "周六");
            now = new Date();
            hour = now.getHours();
            min = now.getMinutes();
            sec = now.getSeconds();
            if (hour < 10) {
                hour = "0" + hour;
            }
            if (min < 10) {
                min = "0" + min;
            }
            if (sec < 10) {
                sec = "0" + sec;
            }
            $("#current-time").html(
                 now.getFullYear() +'-' + mon[now.getMonth()] + '-' + now.getDate() + " " + hour
                + ":" + min + ":" + sec);
        }


        setInterval(GetTime, 1000);




    });


</script>